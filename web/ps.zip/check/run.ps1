using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

# Interact with query parameters or the body of the request.
$echo = $Request.Query.echo
if (-not $echo) {
    $echo = $Request.Body.echo
}

$body = "" | Select-Object @{n="echo";e={""}}

if ($echo && $($echo -match '[^\p{L}\p{Nd}@\.\-]')) {
    $body.echo = "$($echo)"
    $status = [HttpStatusCode]::OK
} else {
    $body.echo = "Invalid object reference"
    $status = 405
}

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = $status
    Body = $($body | ConvertTo-Json)
})
